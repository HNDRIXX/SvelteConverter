import{a as t}from"../chunks/BmwsZ8mM.js";export{t as start};
